export default {
    apiKey: "AIzaSyATxTvXnubJVfAFleU9lCjyhhHezsBlDP0",
    authDomain: "mar09-75100.firebaseapp.com",
    databaseURL: "https://mar09-75100.firebaseio.com",
    projectId: "mar09-75100",
    storageBucket: "mar09-75100.appspot.com",
    messagingSenderId: "191542826815",
    appId: "1:191542826815:web:f4479683776462442e658a",
    measurementId: "G-Z4N4PKCCW6"
  };